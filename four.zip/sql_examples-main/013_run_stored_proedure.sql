exec iu_customer 2, 6, 'customer - 007' ;


-- select * from customers